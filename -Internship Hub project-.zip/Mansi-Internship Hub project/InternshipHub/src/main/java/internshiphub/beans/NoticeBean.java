package internshiphub.beans;

import java.sql.Date;

public class NoticeBean {
private int id;
private String providerId,topic,contents;
private Date date;
public NoticeBean() {
	super();
	// TODO Auto-generated constructor stub
}
public NoticeBean(String providerId, String topic, String contents, Date date) {
	super();
	this.providerId = providerId;
	this.topic = topic;
	this.contents = contents;
	this.date = date;
}

public NoticeBean(String providerId, String topic, String contents) {
	super();
	this.providerId = providerId;
	this.topic = topic;
	this.contents = contents;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getProviderId() {
	return providerId;
}
public void setProviderId(String providerId) {
	this.providerId = providerId;
}
public String getTopic() {
	return topic;
}
public void setTopic(String topic) {
	this.topic = topic;
}
public String getContents() {
	return contents;
}
public void setContents(String contents) {
	this.contents = contents;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}

}
