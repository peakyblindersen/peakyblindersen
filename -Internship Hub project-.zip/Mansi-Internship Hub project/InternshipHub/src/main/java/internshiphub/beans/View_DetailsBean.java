package internshiphub.beans;

public class View_DetailsBean {
private String programId,programName,duration,startDate,endDate,stipend,fees,description;

public View_DetailsBean() {
	super();
	// TODO Auto-generated constructor stub
}

public View_DetailsBean(String programId, String programName, String duration, String startDate, String endDate,
		String stipend, String fees, String description) {
	super();
	this.programId = programId;
	this.programName = programName;
	this.duration = duration;
	this.startDate = startDate;
	this.endDate = endDate;
	this.stipend = stipend;
	this.fees = fees;
	this.description = description;
}

public String getProgramId() {
	return programId;
}

public void setProgramId(String programId) {
	this.programId = programId;
}

public String getProgramName() {
	return programName;
}

public void setProgramName(String programName) {
	this.programName = programName;
}

public String getDuration() {
	return duration;
}

public void setDuration(String duration) {
	this.duration = duration;
}

public String getStartDate() {
	return startDate;
}

public void setStartDate(String startDate) {
	this.startDate = startDate;
}

public String getEndDate() {
	return endDate;
}

public void setEndDate(String endDate) {
	this.endDate = endDate;
}

public String getStipend() {
	return stipend;
}

public void setStipend(String stipend) {
	this.stipend = stipend;
}

public String getFees() {
	return fees;
}

public void setFees(String fees) {
	this.fees = fees;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}


}
