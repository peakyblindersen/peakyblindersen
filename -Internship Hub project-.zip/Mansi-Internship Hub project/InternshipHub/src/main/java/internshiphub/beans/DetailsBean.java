package internshiphub.beans;

public class DetailsBean {
private String providerId,programName,duration,fees,startDate,endDate,perquisite,stipend,description;
private int programId;
public DetailsBean() {
	super();
	// TODO Auto-generated constructor stub
}

public DetailsBean(String providerId,  String programName, String duration, String fees,
		String startDate, String endDate, String perquisite, String stipend, String description) {
	super();
	this.providerId = providerId;
	this.programName = programName;
	this.duration = duration;
	this.fees = fees;
	this.startDate = startDate;
	this.endDate = endDate;
	this.perquisite = perquisite;
	this.stipend = stipend;
	this.description = description;
}

public DetailsBean(String programName, String duration, String fees, String startDate, String endDate,
		String perquisite, String stipend,String providerId) {
	super();
	this.programName = programName;
	this.duration = duration;
	this.fees = fees;
	this.startDate = startDate;
	this.endDate = endDate;
	this.perquisite = perquisite;
	this.stipend = stipend;
	this.providerId=providerId;
}

public String getProviderId() {
	return providerId;
}

public void setProviderId(String providerId) {
	this.providerId = providerId;
}

public int getProgramId() {
	return programId;
}

public void setProgramId(int programId) {
	this.programId = programId;
}

public String getProgramName() {
	return programName;
}

public void setProgramName(String programName) {
	this.programName = programName;
}

public String getDuration() {
	return duration;
}

public void setDuration(String duration) {
	this.duration = duration;
}

public String getFees() {
	return fees;
}

public void setFees(String fees) {
	this.fees = fees;
}

public String getStartDate() {
	return startDate;
}

public void setStartDate(String startDate) {
	this.startDate = startDate;
}

public String getEndDate() {
	return endDate;
}

public void setEndDate(String endDate) {
	this.endDate = endDate;
}

public String getPerquisite() {
	return perquisite;
}

public void setPerquisite(String perquisite) {
	this.perquisite = perquisite;
}

public String getStipend() {
	return stipend;
}

public void setStipend(String stipend) {
	this.stipend = stipend;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

}
