package internshiphub.beans;
import java.sql.Date;
public class FeedbackBean {
private int id,rating;
private String name,email,feedback,box;
private Date date;

public FeedbackBean() {
	super();
}

public FeedbackBean( int rating, String name, String email, String feedback, String box, Date date)
{
	super();
	this.rating = rating;
	this.name = name;
	this.email = email;
	this.feedback = feedback;
	this.box = box;
	this.date = date;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public int getRating() {
	return rating;
}

public void setRating(int rating) {
	this.rating = rating;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getFeedback() {
	return feedback;
}

public void setFeedback(String feedback) {
	this.feedback = feedback;
}

public String getBox() {
	return box;
}

public void setBox(String box) {
	this.box = box;
}

public Date getDate() {
	return date;
}

public void setDate(Date date) {
	this.date = date;
}
}
