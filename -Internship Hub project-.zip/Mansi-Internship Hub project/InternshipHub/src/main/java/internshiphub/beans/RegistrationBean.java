package internshiphub.beans;

import java.sql.Date;

public class RegistrationBean {
private String providerId,password,organizationName,ownerName,email,phone,address,city,domain,about;
private Date date;
public RegistrationBean() {
	super();
	// TODO Auto-generated constructor stub
}
public RegistrationBean(String providerId, String password, String organizationName, String ownerName, String email,
		String phone, String address, String city, String domain, String about, Date date) {
	super();
	this.providerId = providerId;
	this.password = password;
	this.organizationName = organizationName;
	this.ownerName = ownerName;
	this.email = email;
	this.phone = phone;
	this.address = address;
	this.city = city;
	this.domain = domain;
	this.about = about;
	this.date = date;
}

public RegistrationBean(String organizationName, String email, String phone, String address, String domain,
		String about ,String ownerName) {
	super();
	this.organizationName = organizationName;
	this.email = email;
	this.phone = phone;
	this.address = address;
	this.domain = domain;
	this.about = about;
	this.ownerName=ownerName;
}


public RegistrationBean(String providerId, String organizationName, String ownerName, String email, String phone,
		String address, String city, String domain, String about) {
	super();
	this.providerId = providerId;
	this.organizationName = organizationName;
	this.ownerName = ownerName;
	this.email = email;
	this.phone = phone;
	this.address = address;
	this.city = city;
	this.domain = domain;
	this.about = about;
}
public RegistrationBean(String email, String phone, String address, String city, String providerId) {
	super();
	this.email = email;
	this.phone = phone;
	this.address = address;
	this.city = city;
	this.providerId=providerId;
}
public RegistrationBean(String providerId, String password, String organizationName, String email, String phone,
		String city) {
	super();
	this.providerId = providerId;
	this.password = password;
	this.organizationName = organizationName;
	this.email = email;
	this.phone = phone;
	this.city = city;
}

public String getProviderId() {
	return providerId;
}
public void setProviderId(String providerId) {
	this.providerId = providerId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getOrganizationName() {
	return organizationName;
}
public void setOrganizationName(String organizationName) {
	this.organizationName = organizationName;
}
public String getOwnerName() {
	return ownerName;
}
public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getDomain() {
	return domain;
}
public void setDomain(String domain) {
	this.domain = domain;
}
public String getAbout() {
	return about;
}
public void setAbout(String about) {
	this.about = about;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}


}
