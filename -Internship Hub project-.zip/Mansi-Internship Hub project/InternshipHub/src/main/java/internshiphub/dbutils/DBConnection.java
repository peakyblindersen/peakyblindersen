package internshiphub.dbutils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBConnection {
	private static Connection con;
	private static ResourceBundle rb;


	public static Connection openConnection() {
		try {
			rb=ResourceBundle.getBundle("internshiphub/dbutils/dbinfo");
			String url=rb.getString("db.url");
			String id=rb.getString("db.userId");
		    String pass=rb.getString("db.userPassword");
			Class.forName("com.mysql.cj.jdbc.Driver"); //factory method
			con=DriverManager.getConnection(url,id,pass);
			
		}
		catch(SQLException|ClassNotFoundException se) {
			System.out.println(se);
		}
		return con;
	}
	public static void closeConnection() {
		if(con!=null)
			try {
				con.close();
			}
		catch (SQLException e) {
				e.printStackTrace();
			}
	}
	

	  }

