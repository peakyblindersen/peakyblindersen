package internshiphub.provider.servlet;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import internshiphub.beans.DetailsBean;
import internshiphub.beans.NoticeBean;
import internshiphub.dao.ProviderDao;

/**
 * Servlet implementation class Notice
 */
@WebServlet("/Notice")
public class Notice extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Notice() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String providerId=request.getParameter("ProviderId");
		String topic=request.getParameter("NoticeTopic");
		String contents=request.getParameter("Contents");
		java.util.Date d=new java.util.Date();
		long dt=d.getTime();
		java.sql.Date sqlDate=new java.sql.Date(dt);
		System.out.println("sqlDate is "+sqlDate);
		NoticeBean notices=new NoticeBean(providerId,topic,contents,sqlDate);
	    ProviderDao dao=new ProviderDao();
		int status=dao.addNotice(notices);
		if(status>0) {
		request.setAttribute("msg","Your following details is submitted");
		RequestDispatcher dispatcher=request.getRequestDispatcher("/internshipProvider/Notice.jsp");
		dispatcher.forward(request, response);
	}
			}

}
