package internshiphub.provider.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import internshiphub.beans.RegistrationBean;
import internshiphub.dao.ProviderDao;


/**
 * Servlet implementation class ProviderLogin
 */
@WebServlet("/ProviderLogin")
public class ProviderLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProviderLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String providerId=request.getParameter("userid");
		String password=request.getParameter("userpass");
		String value=request.getParameter("chkcookie");
		ProviderDao dao=new ProviderDao();
		RegistrationBean rb=dao.login(providerId,password);
		
		String userinfo=providerId+"#"+password;
		if(rb!=null)
		{
			if(value!=null) {
				Cookie c=new Cookie("providerdetails", userinfo);
				c.setMaxAge(60*60*2);
				response.addCookie(c);
			}
			System.out.println(rb.getEmail()+"login servlet");

		HttpSession hs=request.getSession(); 
		System.out.println("session id is "+hs.getId());
		hs.setAttribute("session_providerId", providerId); 
		hs.setAttribute("providerDetails", rb);
		hs.setAttribute("role","provider");
			response.sendRedirect("/InternshipHub/internshipProvider/ProviderHome.jsp");
		}
		else {
			request.setAttribute("msg","INVALID CREDENTAILS");
			RequestDispatcher dispatcher=request.getRequestDispatcher("/internshipProvider/ProviderLogin.jsp");
			dispatcher.forward(request, response);
		}
	
	}

}
