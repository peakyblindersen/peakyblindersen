package internshiphub.provider.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import internshiphub.beans.RegistrationBean;
import internshiphub.dao.ProviderDao;
/**
 * Servlet implementation class EditProfile
 */
@WebServlet("/EditProfile")
public class EditProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditProfile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String city=request.getParameter("city");
		   String Address=request.getParameter("address");
		   String email=request.getParameter("email");
		   String phone=request.getParameter("phone");
		   HttpSession hs=request.getSession(false);
		   String id=(String)hs.getAttribute("session_providerId");
		   RegistrationBean rb1=new RegistrationBean(email,phone,Address,city,id);
		   ProviderDao dao=new ProviderDao();
		RegistrationBean provider=dao.editProfile(rb1);
		System.out.println(rb1+"  value of rb1");
			if(provider!=null)
			{
				hs.setAttribute("pro_details", provider);
				response.sendRedirect("/InternshipHub/internshipProvider/UpdateProfile.jsp");
			}
		}
	}

