package internshiphub.provider.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import internshiphub.beans.DetailsBean;
import internshiphub.dao.ProviderDao;
import internshiphub.beans.DetailsBean;
import internshiphub.dao.ProviderDao;

/**
 * Servlet implementation class ProgramDetails
 */
@WebServlet("/ProgramDetails")
public class ProgramDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProgramDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String providerId=request.getParameter("ProviderId");
		String programName=request.getParameter("ProgramName");
		String duration=request.getParameter("Dur");
		String fees=request.getParameter("Fees");
		String startDate=request.getParameter("StartDate");
		String endDate=request.getParameter("EndDate");
		String perquisite=request.getParameter("Perquisite");
		String stipend=request.getParameter("Stipend");
		String description=request.getParameter("Description");
		DetailsBean details=new DetailsBean(providerId,programName,duration,fees,startDate,endDate,perquisite,stipend,description);
	    ProviderDao dao=new ProviderDao();
		int status=dao.addDetails(details);
		if(status>0) {
		request.setAttribute("msg","Your following details is submitted");
		RequestDispatcher dispatcher=request.getRequestDispatcher("/internshipProvider/Details.jsp");
		dispatcher.forward(request, response);
	}
}

}
