package internshiphub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import internshiphub.beans.ContactUsBean;
import internshiphub.beans.FeedbackBean;
import internshiphub.beans.NoticeBean;
import internshiphub.beans.RegistrationBean;
import internshiphub.beans.View_DetailsBean;
import internshiphub.dbutils.DBConnection;

public class CommonDao {
public int postFeedback(FeedbackBean fb) {
	int student = 0;
	Connection con=DBConnection.openConnection();
	PreparedStatement ps=null;
	try {
		String insertQuery="insert into feedback (Name,Email,Date,FeedbackText,Rating,CheckBox) values(?,?,?,?,?,?)";
		ps=con.prepareStatement(insertQuery);
		ps.setString(1,fb.getName());
		ps.setString(2,fb.getEmail());
		ps.setDate(3,fb.getDate());
		ps.setString(4,fb.getFeedback());
		ps.setInt(5,fb.getRating());
		ps.setString(6,fb.getBox());
		System.out.println(ps);
	student=ps.executeUpdate();
			}
	catch(SQLException se) {
		System.out.println(se);
	}
	return student;
}
public int postContact(ContactUsBean cu) {
	int contact=0;
	Connection con=DBConnection.openConnection();
	PreparedStatement ps=null;
	try {
		String insertQuery="insert into contactus(Name,Email,Phone,Question,Date) values(?,?,?,?,?)";
ps=con.prepareStatement(insertQuery);
ps.setString(1, cu.getName());
ps.setString(2, cu.getEmail());
ps.setString(3, cu.getPhone());
ps.setString(4, cu.getQuestion());
ps.setDate(5, cu.getDate());
System.out.println(ps);
contact=ps.executeUpdate();
	}
	catch(SQLException se) {
		se.printStackTrace();
	}
	return contact;
}
public int postRegistration(RegistrationBean rb) {
	int reg=0;
	Connection con=DBConnection.openConnection();
	PreparedStatement ps=null;
	try {//ProviderId, Password, OrganizationName, OwnerName, PhoneNumber, Email, Address, City, Domain, AboutOrganization
		String insertQuery="insert into provider(ProviderId, Password, OrganizationName, OwnerName,Email, PhoneNumber, Address, City, Domain, AboutOrganization,Date) values(?,?,?,?,?,?,?,?,?,?,?)";
	ps=con.prepareStatement(insertQuery);
	ps.setString(1, rb.getProviderId());
	ps.setString(2, rb.getPassword());
	ps.setString(3, rb.getOrganizationName());
	ps.setString(4, rb.getOwnerName());
	ps.setString(5, rb.getEmail());
	ps.setString(6, rb.getPhone());
	ps.setString(7, rb.getAddress());
	ps.setString(8, rb.getCity());
	ps.setString(9, rb.getDomain());
	ps.setString(10, rb.getAbout());
	ps.setDate(11, rb.getDate());
	System.out.println(ps);
	reg=ps.executeUpdate();
	}
	catch(SQLException se) {
		se.printStackTrace();
	}
	return reg;
}
public ArrayList<View_DetailsBean> viewDetails()
{ 
	ArrayList<View_DetailsBean>detailList=new ArrayList<>();
	
	Connection con=DBConnection.openConnection();
	String select_query="select*from program_details";
	PreparedStatement ps=null;
	ResultSet rs=null;
	try
	{
		ps=con.prepareStatement(select_query);
		rs=ps.executeQuery();
		while(rs.next())
		{
			String id=rs.getString("programId");
			String name=rs.getString("programName");
			String fees=rs.getString("fees");
			String duration=rs.getString("duration");
			String startDate=rs.getString("startDate");
			String endDate=rs.getString("endDate");
			String stipend=rs.getString("stipend");
			String desc=rs.getString("description");
			View_DetailsBean db=new View_DetailsBean(id,name,fees,duration,startDate,endDate,stipend,desc);
			detailList.add(db);
		}
		}
	catch(SQLException se)
	{
		se.printStackTrace();
	}
	return detailList;
}
public  ArrayList<RegistrationBean> organizationwiseProviders(String OgranizationName)
{
	ArrayList<RegistrationBean>providerList=new ArrayList<>();
	 Connection con=DBConnection.openConnection(); 
	 PreparedStatement ps=null; 
	 ResultSet rs=null; 
	 String strsql="select*from provider where OrganizationName=?";
	 try {
ps=con.prepareStatement(strsql); 
ps.setString(1, OgranizationName);
System.out.println(ps); 
rs=ps.executeQuery(); 
while(rs.next()) { 
	  String pid=rs.getString("providerid");
	  String orgname=rs.getString("organizationName");
	  String ownname=rs.getString("ownerName");
	  String email=rs.getString("email");
	  String phone=rs.getString("phoneNumber"); 
	  String address=rs.getString("address");
	  String city=rs.getString("city");
	  String domain=rs.getString("domain");
	  String about=rs.getString("about");
	  RegistrationBean rb=new RegistrationBean(pid,orgname,ownname,email, phone, address, city,domain, about);
	  
	  } 
} 
	 catch(SQLException se) 
	 { 
		 se.printStackTrace();
}
	 return providerList;
}
public ArrayList<RegistrationBean>citywiseProviders(String cityname)
{
	  System.out.println("City name is "+cityname);
	  ArrayList<RegistrationBean>providerList=new ArrayList<>();
	  Connection con=DBConnection.openConnection();
	  PreparedStatement ps=null;
	  ResultSet rs=null;
	  try {
		  String selectQuery="select * from provider where City=?";
		  ps=con.prepareStatement(selectQuery);
		  ps.setString(1, cityname);
		  rs=ps.executeQuery();
		  while(rs.next()) {
			  String pid=rs.getString("providerid");
			  String orgname=rs.getString("organizationName");
			  String ownname=rs.getString("ownerName");
			  String email=rs.getString("email");
			  String phone=rs.getString("phoneNumber"); 
			  String address=rs.getString("address");
			  String city=rs.getString("city");
			  String domain=rs.getString("domain");
			  String about=rs.getString("aboutOrganization");
			  RegistrationBean rb=new RegistrationBean(pid,orgname,ownname,email, phone, address, city,domain, about);
			  providerList.add(rb);
	  }
	  }
	  catch(SQLException se) {
		  se.printStackTrace();
	  }
	  return providerList;
}
public ArrayList<RegistrationBean>orgwiseProviders(String organiname)
{
	  //System.out.println("City name is "+cityname);
	  ArrayList<RegistrationBean>providerList=new ArrayList<>();
	  Connection con=DBConnection.openConnection();
	  PreparedStatement ps=null;
	  ResultSet rs=null;
	  try {
		  String selectQuery="select * from provider where OrganizationName=?";
		  ps=con.prepareStatement(selectQuery);
		  ps.setString(1, organiname);
		  rs=ps.executeQuery();
		  while(rs.next()) {
			  String pid=rs.getString("providerid");
			  String orgname=rs.getString("organizationName");
			  String ownname=rs.getString("ownerName");
			  String email=rs.getString("email");
			  String phone=rs.getString("phoneNumber"); 
			  String address=rs.getString("address");
			  String city=rs.getString("city");
			  String domain=rs.getString("domain");
			  String about=rs.getString("aboutOrganization");
			  RegistrationBean rb=new RegistrationBean(pid,orgname,ownname,email, phone, address, city,domain, about);
			  providerList.add(rb);
	  }
	  }
	  catch(SQLException se) {
		  se.printStackTrace();
	  }
	  return providerList;
}
}
