package internshiphub.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import internshiphub.beans.FeedbackBean;
import internshiphub.beans.RegistrationBean;
import internshiphub.dbutils.DBConnection;
import internshiphub.beans.ContactUsBean;

public class AdminDao {
	public ArrayList<FeedbackBean> viewFeedback(){
		 ArrayList<FeedbackBean>feedbackList=new ArrayList<>(); 
		 Connection con=DBConnection.openConnection(); 
		 String select_query="select*from feedback"; 
		 PreparedStatement ps=null; 
		 ResultSet rs=null; 
		 try { 
			 ps=con.prepareStatement(select_query);
		  rs=ps.executeQuery(); 
		  while(rs.next()) {
			  String nm=rs.getString("Name");//read the data from given column name
			  String email=rs.getString("Email");
			  int rating=rs.getInt("Rating");
		 String feedback=rs.getString("FeedBackText");
		 String agree=rs.getString("CheckBox"); 
		 Date date=rs.getDate("Date");
		  FeedbackBean pb=new FeedbackBean(rating,email,nm,feedback,agree,date);
		  pb.setId(rs.getInt(("FeedbackId")));
		 feedbackList.add(pb);//adding object of bean class in ArrayList
		 }
		 }
		  catch(SQLException se) 
		 {
			 se.printStackTrace();
			  } 
		 return feedbackList;
}
	
	public int deleteFeedBack(String[]idArray)
	{ 
		  Connection con=DBConnection.openConnection(); 
		  PreparedStatement ps=null; 
		  String deleteQuery="delete from feedback where FeedbackId=?"; 
		  int flag=0; 
		  try 
		  {
	  ps=con.prepareStatement(deleteQuery);
	 
	  for(int i=0;i<idArray.length;i++) 
	  { 
		  int id=Integer.parseInt(idArray[i]);
	 ps.setInt(i,id);
	 ps.executeUpdate();
	 }
	 
	 //batch processing 
	  for(int i=0;i<idArray.length;i++)
	  {
		  int id=Integer.parseInt(idArray[i]); ps.setInt(1,id); ps.addBatch();//adding data in batch 
	  }
	  
	  int arr[]=ps.executeBatch();//sending whole batch to rdbms orexecution
	 
	 for(int i=0;i<arr.length;i++)
	 { 
		 if(arr[i]>0) 
	 {
			 flag=1;
			 } 
		 else { 
			 flag=0;
	  break; 
	  } 
		 }
	 }
	  catch(SQLException se)
		  { 
		  se.printStackTrace(); 
		  try 
		  { 
			  con.rollback();
		  }
	 catch(SQLException e) 
		  { 
		 e.printStackTrace(); 
		 } 
		  } 
		  return flag; 
}
	public ArrayList<ContactUsBean> viewContact()
	 {
	 ArrayList<ContactUsBean>contactList=new ArrayList<>(); 
	 Connection con=DBConnection.openConnection();
	 String select_query="select * from contactus"; 
	 PreparedStatement ps=null; 
	 ResultSet rs=null; 
	 try 
	 {
	 ps=con.prepareStatement(select_query);
	 rs=ps.executeQuery();//rs has the address 
	 while(rs.next())
	 { //put cursor on row and check for data availability
	 String nm=rs.getString("Name");//read the data from given column name 
	 String email=rs.getString("Email");
	 String phone=rs.getString("Phone");
	 String question=rs.getString("Question"); 
	 Date date=rs.getDate("Date"); 
	 ContactUsBean pb=new ContactUsBean(nm,email,phone,question,date); 
	 contactList.add(pb);//adding object of bean class in ArrayList 
	 }
	 }
	 catch(SQLException se)
	 { 
		 se.printStackTrace();
	 } 
	 return contactList;
}
	public ArrayList<RegistrationBean> viewProvider()
	 {
	 ArrayList<RegistrationBean>providerList=new ArrayList<>(); 
	 Connection con=DBConnection.openConnection();
	 String select_query="select * from provider"; 
	 PreparedStatement ps=null; 
	 ResultSet rs=null; 
	 try 
	 {
	 ps=con.prepareStatement(select_query);
	 rs=ps.executeQuery();//rs has the address 
	 while(rs.next())
	 { //put cursor on row and check for data availability
	 String id=rs.getString("ProviderId");//read the data from given column name 
	 String email=rs.getString("Email");
	 String phone=rs.getString("PhoneNumber");
	 String orgname=rs.getString("OrganizationName");//read the data from given column name 
	 String owname=rs.getString("OwnerName");
	 String add=rs.getString("Address");
	 String city=rs.getString("City");
	 String domain=rs.getString("Domain");
	 String about=rs.getString("AboutOrganization");
	 RegistrationBean pb=new RegistrationBean(id,orgname,owname,email,phone,add,city,domain,about); 
	 providerList.add(pb);//adding object of bean class in ArrayList 
	 }
	 }
	 catch(SQLException se)
	 { 
		 se.printStackTrace();
	 } 
	 return providerList;
}
	public int deleteProvider(String[]idArray)
	{ 
		  Connection con=DBConnection.openConnection(); 
		  PreparedStatement ps=null; 
		  String deleteQuery="delete from provider where ProviderId=?"; 
		  int flag=0; 
		  try 
		  {
	  ps=con.prepareStatement(deleteQuery);
	 
	  for(int i=0;i<idArray.length;i++) 
	  { 
		  int id=Integer.parseInt(idArray[i]);
	 ps.setInt(i,id);
	 ps.executeUpdate();
	 }
	 
	 //batch processing 
	  for(int i=0;i<idArray.length;i++)
	  {
		  int id=Integer.parseInt(idArray[i]); ps.setInt(1,id); ps.addBatch();//adding data in batch 
	  }
	  
	  int arr[]=ps.executeBatch();//sending whole batch to rdbms orexecution
	 
	 for(int i=0;i<arr.length;i++)
	 { 
		 if(arr[i]>0) 
	 {
			 flag=1;
			 } 
		 else { 
			 flag=0;
	  break; 
	  } 
		 }
	 }
	  catch(SQLException se)
		  { 
		  se.printStackTrace(); 
		  try 
		  { 
			  con.rollback();
		  }
	 catch(SQLException e) 
		  { 
		 e.printStackTrace(); 
		 } 
		  } 
		  return flag; 

}
}