package internshiphub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import internshiphub.beans.DetailsBean;
import internshiphub.beans.NoticeBean;
import internshiphub.beans.RegistrationBean;
import internshiphub.dbutils.DBConnection;
import internshiphub.beans.RegistrationBean;

public class ProviderDao {
	public int addDetails(DetailsBean d) {
		 int status=0;

System.out.println(d.getProviderId()); 
System.out.println(d.getProgramId());
 System.out.println(d.getProgramName()); 
 System.out.println(d.getDuration());
 System.out.println(d.getFees());
 System.out.println(d.getStartDate());
 System.out.println(d.getEndDate());
 System.out.println(d.getPerquisite());
 System.out.println(d.getStipend());
 System.out.println(d.getDescription());
 Connection con= DBConnection.openConnection();
PreparedStatement ps=null; 
try { 
	 String insertQuery="insert into program_details(ProviderId, ProgramName, Duration, Fees, StartDate, EndDate, Perquisite, Stipend, Description)values(?,?,?,?,?,?,?,?,?)"; 
    ps=con.prepareStatement(insertQuery); 
 ps.setString(1,d.getProviderId()); 
  ps.setString(2, d.getProgramName()); 
 ps.setString(3, d.getDuration());
 ps.setString(4, d.getFees());
 ps.setString(5, d.getStartDate());
 ps.setString(6, d.getEndDate());
 ps.setString(7, d.getPerquisite());
 ps.setString(8, d.getStipend());
 ps.setString(9, d.getDescription());
 System.out.println(ps);
status=ps.executeUpdate();
} 
	 catch(SQLException se)
	 {
 System.out.println(se);
 }
	 finally 
	 { 
		 try
		 {
		 if(ps!=null) 
			  ps.close();
				 }
 catch(SQLException e) 
		 {
	 e.printStackTrace(); 
	 }
    DBConnection.closeConnection();
} 
return status; 
}
	public RegistrationBean login(String ProviderId, String password) 
	{ 
	 Connection con=DBConnection.openConnection(); 
	  PreparedStatement ps=null;
	  ResultSet rs=null; 
	  RegistrationBean rb=null; 
	  String strsql="select * from provider where ProviderId=? and Password=?"; 
	  try 
	  {
	  ps=con.prepareStatement(strsql);
	  ps.setString(1,ProviderId);
	  ps.setString(2, password); 
	  System.out.println(ps); //String providerId, String password, String organizationName, String email, String phone,
		//String city)
	   rs=ps.executeQuery();
	    if(rs.next()==true) { 
		  rb=new RegistrationBean(); 
	  String orgname=rs.getString("organizationName");
	  String email=rs.getString("email");
	  String city=rs.getString("city");
	  String phone=rs.getString("phoneNumber"); 
	  String address=rs.getString("address");
	  String pid=rs.getString("providerid");
	  rb.setCity(city);
	  rb.setEmail(email);
	  rb.setOrganizationName(orgname); 
	  rb.setPhone(phone);
	  rb.setAddress(address);
	  rb.setProviderId(pid);
	  } 
	    } 
	  catch(SQLException se) {
	  se.printStackTrace(); 
	  }
	  return rb; 
	  }
	public RegistrationBean viewProfile(String ProviderId) {
		 Connection con=DBConnection.openConnection(); 
		 PreparedStatement ps=null; 
		 RegistrationBean rb=null; 
		 ResultSet rs=null; 
		 String strsql="select * from provider where ProviderId=?";
		 try {
	 ps=con.prepareStatement(strsql); 
	 ps.setString(1, ProviderId);
	 System.out.println(ps); 
	 rs=ps.executeQuery(); 
	 if(rs.next()==true) { 
		 rb=new RegistrationBean(); 
		 String orgname=rs.getString("OrganizationName"); 
		 String email=rs.getString("Email");
		 String phone=rs.getString("PhoneNumber"); 
		 String about=rs.getString("AboutOrganization");
		 String address=rs.getString("Address");
		 String domain=rs.getString("Domain"); 
		 String ownname=rs.getString("OwnerName"); 
		 rb.setAbout(about);
	  rb.setEmail(email); 
	 rb.setOrganizationName(orgname);
	  rb.setPhone(phone);
	 rb.setOwnerName(ownname);
	 rb.setDomain(domain);
	  rb.setAddress(address);
	  } 
	 } 
		 catch(SQLException se) 
		 { 
			 se.printStackTrace();
	 }
		 return rb;
		 } 
	 
	public RegistrationBean editProfile(RegistrationBean rb1) { 
		 int status=0; 
	 RegistrationBean rb=null; 
	 Connection con=DBConnection.openConnection();
	 PreparedStatement ps=null; 
	 String updateQuery="update provider set Email=?,Phonenumber=?,City=?,Address=? where ProviderId=?";
	  try {
		  ps=con.prepareStatement(updateQuery); 
	 ps.setString(1, rb1.getEmail());
	 ps.setString(2, rb1.getPhone()); 
	 ps.setString(3, rb1.getCity());
	 ps.setString(4, rb1.getAddress()); 
	 ps.setString(5, rb1.getProviderId());
	 System.out.println(ps);
	 status=ps.executeUpdate(); 
	 if(status>0) { 
		 String strsql="select* from provider where ProviderId=?"; 
		 PreparedStatement ps1=null;
	 ResultSet rs=null;
	 ps1=con.prepareStatement(strsql);
	  ps1.setString(1,rb1.getProviderId()); 
	  rs=ps1.executeQuery();
	  rs.next();
	  String email=rs.getString("Email");
	  String phone=rs.getString("Phonenumber");
	  String city=rs.getString("City");
	  String address=rs.getString("Address"); 
	  String providerid=rs.getString("ProviderId");
	  rb1=new RegistrationBean(email,phone,address,city,providerid);
	  
	  System.out.println(rb1);
	 } 
	 } 
	  catch(SQLException se) { 
		  se.printStackTrace(); 
		  } 
	  return rb1; 
		  }
	
	public DetailsBean updateDetails(DetailsBean db) { 
		 int status=0; 
	 DetailsBean db1=null; 
	 Connection con=DBConnection.openConnection();
	 PreparedStatement ps=null; 
	 String updateQuery="update program_details set ProgramName=?,Duration=?,Fees=?,StartDate=?,EndDate=?,Perquisite=?,Stipend=? where ProviderId=?";
	  try {
		  ps=con.prepareStatement(updateQuery); 
	 ps.setString(1, db1.getProgramName());
	 ps.setString(2, db1.getDuration());
	 ps.setString(3, db1.getFees()); 
	 ps.setString(4, db1.getStartDate());
	 ps.setString(5, db1.getEndDate()); 
	 ps.setString(6, db1.getPerquisite());
	 ps.setString(7, db1.getStipend());
	 System.out.println(ps);
	 status=ps.executeUpdate(); 
	 if(status>0) { 
		 String strsql="select * from program_details where ProviderId=?"; 
		 PreparedStatement ps1=null;
	  ResultSet rs=null;
	  ps1=con.prepareStatement(strsql);
	  ps1.setString(1,db1.getProviderId()); 
	  rs=ps1.executeQuery();
	  rs.next();
	  String id=rs.getString("ProviderId");
	  String proname=rs.getString("ProgramName");
	  String duration=rs.getString("Dur");
	   String fees=rs.getString("Fees");
	  String startDate=rs.getString("StartDate");
	   String endDate=rs.getString("EndDate");
	   String perquisite=rs.getString("Perquisite");
	   String stipend=rs.getString("Stipend");
	   db1=new DetailsBean(id,proname,duration,fees,startDate,endDate,perquisite,stipend);
	  System.out.println(db1);
	 } 
	 } 
	  catch(SQLException se) { 
		  se.printStackTrace(); 
		  } 
	  return db1;
		  } 
	public ArrayList<DetailsBean> viewDetails(String pid)
	 {
	 ArrayList<DetailsBean>detailList=new ArrayList<>(); 
	 Connection con=DBConnection.openConnection();
	 String select_query="select * from program_details where providerid=?"; 
	 PreparedStatement ps=null; 
	 ResultSet rs=null; 
	 try 
	 {
	 ps=con.prepareStatement(select_query);
	 ps.setString(1, pid);
	 rs=ps.executeQuery();//rs has the address 
	 while(rs.next())
	 { 
	 String id=rs.getString("ProviderId");//read the data from given column name 
	 String name=rs.getString("ProgramName");
	 String dur=rs.getString("Duration");
	 String fees=rs.getString("Fees");//read the data from given column name 
	 String startDate=rs.getString("StartDate");
	 String endDate=rs.getString("EndDate");
	 String perquisite=rs.getString("Perquisite");
	 String stipend=rs.getString("Stipend");
	 System.out.println("stipned"+stipend);
	 DetailsBean db=new DetailsBean(name,dur,fees,startDate,endDate,perquisite,stipend,id); 
	 detailList.add(db);//adding object of bean class in ArrayList 
	 }
	 }
	 catch(SQLException se)
	 { 
		 se.printStackTrace();
	 } 
	 return detailList;
	 }
	
	public int deleteDetails(String[]idArray)
	{ 
		  Connection con=DBConnection.openConnection(); 
		  PreparedStatement ps=null; 
		  String deleteQuery="delete from program_details where ProviderId=?"; 
		  int flag=0; 
		  try 
		  {
	  ps=con.prepareStatement(deleteQuery);
	 
	  for(int i=0;i<idArray.length;i++) 
	  { 
		  int id=Integer.parseInt(idArray[i]);
	 ps.setInt(i,id);
	 ps.executeUpdate();
	 }
	 
	 //batch processing 
	  for(int i=0;i<idArray.length;i++)
	  {
		  int id=Integer.parseInt(idArray[i]); ps.setInt(1,id); ps.addBatch();//adding data in batch 
	  }
	  
	  int arr[]=ps.executeBatch();//sending whole batch to rdbms orexecution
	 
	 for(int i=0;i<arr.length;i++)
	 { 
		 if(arr[i]>0) 
	 {
			 flag=1;
			 } 
		 else { 
			 flag=0;
	  break; 
	  } 
		 }
	 }
	  catch(SQLException se)
		  { 
		  se.printStackTrace(); 
		  try 
		  { 
			  con.rollback();
		  }
	 catch(SQLException e) 
		  { 
		 e.printStackTrace(); 
		 } 
		  } 
		  return flag; 
}

public int addNotice(NoticeBean n) 
{
		 int status=0;
System.out.println(n.getProviderId()); 
System.out.println(n.getTopic());
System.out.println(n.getContents());
Connection con= DBConnection.openConnection();
PreparedStatement ps=null; 
try { 
	 String insertQuery="insert into notice(ProviderId, NoticeTopic,NoticeContents,Date)values(?,?,?,?)"; 
    ps=con.prepareStatement(insertQuery); 
   ps.setString(1,n.getProviderId()); 
  ps.setString(2, n.getTopic()); 
  ps.setString(3, n.getContents());
  ps.setDate(4, n.getDate());
  System.out.println(ps);
  status=ps.executeUpdate();
  } 
  	 catch(SQLException se)
  	 {
   System.out.println(se);
   }
  	 finally 
  	 { 
  		 try
  		 {
  		 if(ps!=null) 
  			  ps.close();
  				 }
   catch(SQLException e) 
  		 {
  	 e.printStackTrace(); 
  	 }
}
return status;
}
public ArrayList<NoticeBean> viewNotices()
{
ArrayList<NoticeBean>noticeList=new ArrayList<>(); 
Connection con=DBConnection.openConnection();
String select_query="select * from notice"; 
PreparedStatement ps=null; 
ResultSet rs=null; 
try 
{
ps=con.prepareStatement(select_query);
rs=ps.executeQuery();
while(rs.next())
{ 
String id=rs.getString("ProviderId"); 
System.out.println("id is "+id);
String topic =rs.getString("NoticeTopic");
String contents=rs.getString("NoticeContents");

NoticeBean nb=new NoticeBean(id,topic,contents); 
noticeList.add(nb);
}
}
catch(SQLException se)
{ 
	 se.printStackTrace();
} 
return noticeList;
}
}