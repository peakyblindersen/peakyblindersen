package internshiphub.common.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import internshiphub.beans.FeedbackBean;
import internshiphub.dao.CommonDao;

/**
 * Servlet implementation class Feedback
 */
@WebServlet("/Feedback")
public class Feedback extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Feedback() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
String name=request.getParameter("txtname");
String email=request.getParameter("txtemail");
String rating=request.getParameter("cmbrating");
String feedback=request.getParameter("txtfeedback");
String box=request.getParameter("chkagree");
java.util.Date d=new java.util.Date();
long dt=d.getTime();
java.sql.Date sqlDate=new java.sql.Date(dt);
System.out.println("sqlDate is "+sqlDate);
FeedbackBean fb=new FeedbackBean(Integer.parseInt(rating),name,email,feedback,box,sqlDate);
CommonDao dao=new CommonDao();
int feedback1=dao.postFeedback(fb);
if(feedback1>0) {
	fb.setBox(box);
	request.setAttribute("msg","Your feedback is submitted");
	RequestDispatcher dispatcher=request.getRequestDispatcher("/jsp/Feedback.jsp");
	dispatcher.forward(request, response);
}
}
}
